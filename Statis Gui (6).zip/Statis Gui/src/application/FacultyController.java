package application;
import java.io.FileNotFoundException;
import java.io.IOException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
public class FacultyController {
	private int EmailNo;
	@FXML
	private Button b1 ;
	@FXML
	private Button b2 ;
	@FXML
	private Button b3 ;
	@FXML
	private Button b4 ;
	@FXML
	private Button b5 ;
	@FXML
	private Button b6 ;
	@FXML
	private Button b7 ;
	@FXML
	private Button b8 ;
	@FXML
	private Button b9 ;
	@FXML
	private TextField em1 ;
	@FXML
	private TextField t2 ;
	@FXML
	private PasswordField ps2 ;
	@FXML
	private Label Head ;
	public void start(String head,int no){
		this.EmailNo = no;
		Head.setText(head);
	}
	public void SignOut(ActionEvent event){
		Stage primaryStage = new Stage();
		try {
			Parent root = FXMLLoader.load(getClass().getResource("/application/Open.fxml"));
			Scene scene = new Scene(root,600,600);
			scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			primaryStage.setScene(scene);
			primaryStage.show();
			((Node) (event.getSource())).getScene().getWindow().hide();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	public void ViewAllCourses(ActionEvent event){
		Stage primaryStage = new Stage();
		try {
			Parent root = FXMLLoader.load(getClass().getResource("/application/AllCourses.fxml"));
			Scene scene = new Scene(root,600,600);
			scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			primaryStage.setScene(scene);
			primaryStage.show();
		}
		catch(Exception e) {
		e.printStackTrace();
		}
	}
	public void bookRoom(ActionEvent event){
		Stage primaryStage = new Stage();
		try {
		FXMLLoader loader = new FXMLLoader(getClass().getResource("/application/FacultyBookRoom.fxml"));
		
		//Parent root = FXMLLoader.load(getClass().getResource("/application/Faculty.fxml"));
		Scene scene = new Scene(loader.load(),600,600);
		//Scene scene = new Scene(root,600,600);
		scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
		primaryStage.setScene(scene);
		FacultyBookRoomController controller = loader.<FacultyBookRoomController>getController();
		controller.start(EmailNo);
				
		primaryStage.show();
	} catch(Exception e) {
		e.printStackTrace();
	}
	}
	public void RoomStatus(ActionEvent event){
		Stage primaryStage = new Stage();
		try {
		
		
		Parent root = FXMLLoader.load(getClass().getResource("/application/RoomTable.fxml"));
		Scene scene = new Scene(root,600,600);
		scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
		primaryStage.setScene(scene);
				
		primaryStage.show();
		}
		catch(Exception e){
			
		}
	}
	public void PersonalBookings(ActionEvent event){
		Stage primaryStage = new Stage();
		try {
		FXMLLoader loader = new FXMLLoader(getClass().getResource("/application/PersonalBookedRoom.fxml"));
		
		//Parent root = FXMLLoader.load(getClass().getResource("/application/Faculty.fxml"));
		Scene scene = new Scene(loader.load(),600,600);
		//Scene scene = new Scene(root,600,600);
		scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
		primaryStage.setScene(scene);
		PersonalBookedRoomController controller = loader.<PersonalBookedRoomController>getController();
		controller.StudentTeller(EmailNo,2);
				
		primaryStage.show();
	} catch(Exception e) {
		e.printStackTrace();
	}
	}
	public void Add(ActionEvent event) throws IOException,FileNotFoundException{
		String courseAcro = t2.getText();
		((StudentProfile)Main.getStuProfs().getStudentData().get(EmailNo)).add(courseAcro);
		Main.Save();
	}
	public void Remove(ActionEvent event)  throws IOException,FileNotFoundException{
		String courseAcro = t2.getText();
		((StudentProfile)Main.getStuProfs().getStudentData().get(EmailNo)).delete(courseAcro);
		Main.Save();
		
	}
}
