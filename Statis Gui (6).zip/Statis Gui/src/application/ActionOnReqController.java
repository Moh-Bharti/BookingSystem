package application;

import java.io.FileNotFoundException;
import java.io.IOException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;

public class ActionOnReqController {
	@FXML
	private Button b1;
	@FXML
	private Button b2;
	@FXML
	private TextField t1;
	
	public void Add(ActionEvent event) throws IOException,FileNotFoundException{
		int teller = Integer.parseInt(t1.getText()) -1;
		RoomRequest curr = (RoomRequest)(Main.getRoomRequests().getRequests().get(teller));
		String day = curr.getDay();
		String searcher = curr.getStartTime()+"-"+curr.getEndTime()+"_"+curr.getRoomNo();
		if(day.equals("Monday")){
			try{
				Main.getAllRooms().TimingRoomAdd(0,searcher);
			}
			catch(Exception e){
				
			}
		}
		else if(day.equals("Tuesday")){
			try{
				Main.getAllRooms().TimingRoomAdd(1,searcher);
			}
			catch(Exception e){
				
			}
		}
		else if(day.equals("Wednesday")){
			try{
				Main.getAllRooms().TimingRoomAdd(2,searcher);
			}
			catch(Exception e){
				
			}
		}
		else if(day.equals("Thursday")){
			try{
				Main.getAllRooms().TimingRoomAdd(3,searcher);
			}
			catch(Exception e){
				
			}
		}
		else{
			try{
				Main.getAllRooms().TimingRoomAdd(4,searcher);
			}
			catch(Exception e){
				
			}
		}
		String ad =day+"&"+searcher;
		((StudentProfile)(Main.getStuProfs().getStudentData().get(teller))).getBookedrooms().add(ad);
		((StudentProfile)(Main.getStuProfs().getStudentData().get(teller))).getReqs().remove(ad);
		Main.getRoomRequests().getRequests().remove(teller);
		
		Main.Save();
	}
	public void cancel(ActionEvent event)  throws IOException,FileNotFoundException{
		int teller = Integer.parseInt(t1.getText()) -1;
		RoomRequest curr = (RoomRequest)(Main.getRoomRequests().getRequests().get(teller));
		String day = curr.getDay();
		String searcher = curr.getStartTime()+"-"+curr.getEndTime()+"_"+curr.getRoomNo();
		String ad =day+"&"+searcher;
		((StudentProfile)(Main.getStuProfs().getStudentData().get(teller))).getReqs().remove(ad);
		Main.getRoomRequests().getRequests().remove(teller);
		
		Main.Save();
		
	}
}
