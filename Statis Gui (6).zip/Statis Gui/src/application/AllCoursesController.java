package application;

import java.net.URL
;
import java.util.ResourceBundle;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

public class AllCoursesController implements Initializable {
	@FXML
	private TableView<TableCourse> table;
	@FXML
	private TableColumn<TableCourse,String> MandatoryORElective;
	@FXML
	private TableColumn<TableCourse,String> Name;
	@FXML
	private TableColumn<TableCourse,String> Code;
	@FXML
	private TableColumn<TableCourse,String> Instructer;
	@FXML
	private TableColumn<TableCourse,String> Credits;
	@FXML
	private TableColumn<TableCourse,String> Acronym;
	@FXML
	private TableColumn<TableCourse,String> t7;
	@FXML
	private TableColumn<TableCourse,String> t8;
	@FXML
	private TableColumn<TableCourse,String> t9;
	@FXML
	private TableColumn<TableCourse,String> t10;
	@FXML
	private TableColumn<TableCourse,String> t11;
	@FXML
	private TableColumn<TableCourse,String> t12;
	@FXML
	private TableColumn<TableCourse,String> t13;
	@FXML
	private TableColumn<TableCourse,String> t14;
	@FXML
	private TableColumn<TableCourse,String> t15;
	
	public ObservableList<TableCourse> CourseList = FXCollections.observableArrayList();
	
	@Override
	public void initialize(URL location,ResourceBundle resources){
		MandatoryORElective.setCellValueFactory(new PropertyValueFactory<TableCourse,String>("CourseType"));
		Name.setCellValueFactory(new PropertyValueFactory<TableCourse,String>("CourseName"));
		Code.setCellValueFactory(new PropertyValueFactory<TableCourse,String>("CourseCode"));
		Instructer.setCellValueFactory(new PropertyValueFactory<TableCourse,String>("Instructor"));
		Credits.setCellValueFactory(new PropertyValueFactory<TableCourse,String>("Credits"));
		Acronym.setCellValueFactory(new PropertyValueFactory<TableCourse,String>("Acronym"));
		t7.setCellValueFactory(new PropertyValueFactory<TableCourse,String>("Mon"));
		t8.setCellValueFactory(new PropertyValueFactory<TableCourse,String>("Tue"));
		t9.setCellValueFactory(new PropertyValueFactory<TableCourse,String>("Wed"));
		t10.setCellValueFactory(new PropertyValueFactory<TableCourse,String>("Thur"));
		t11.setCellValueFactory(new PropertyValueFactory<TableCourse,String>("Fri"));
		t12.setCellValueFactory(new PropertyValueFactory<TableCourse,String>("Tut"));
		t13.setCellValueFactory(new PropertyValueFactory<TableCourse,String>("Lab"));
		t14.setCellValueFactory(new PropertyValueFactory<TableCourse,String>("PreConditions"));
		t15.setCellValueFactory(new PropertyValueFactory<TableCourse,String>("PostConditions"));
		int counter = Main.getMainTimeTable().getCourseData().size();
		for(int i = 0 ; i<counter;i++){
		CourseList.add(new TableCourse(((courses)(Main.getMainTimeTable().getCourseData().get(i))).getCourseType(),((courses)(Main.getMainTimeTable().getCourseData().get(i))).getCourseName(),((courses)(Main.getMainTimeTable().getCourseData().get(i))).getCourseCode(),((courses)(Main.getMainTimeTable().getCourseData().get(i))).getInstructor(),((courses)(Main.getMainTimeTable().getCourseData().get(i))).getCredits(),((courses)(Main.getMainTimeTable().getCourseData().get(i))).getAcronym(),((courses)(Main.getMainTimeTable().getCourseData().get(i))).getMon(),((courses)(Main.getMainTimeTable().getCourseData().get(i))).getTue(),((courses)(Main.getMainTimeTable().getCourseData().get(i))).getWed(),((courses)(Main.getMainTimeTable().getCourseData().get(i))).getThur(),((courses)(Main.getMainTimeTable().getCourseData().get(i))).getFri(),((courses)(Main.getMainTimeTable().getCourseData().get(i))).getTut(),((courses)(Main.getMainTimeTable().getCourseData().get(i))).getLab(),((courses)(Main.getMainTimeTable().getCourseData().get(i))).getPreConditions(),((courses)(Main.getMainTimeTable().getCourseData().get(i))).getPostConditions()));
		}
		table.setItems(CourseList);
		
	}

}
