package application;

import java.net.URL;
import java.util.ResourceBundle;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

public class PersonalBookedRoomController implements Initializable {
	@FXML
	private TableView<PBR> table;
	@FXML
	private TableColumn<PBR,String> t1;
	private int EmailtNo;
	private int userTeller;
	
public ObservableList<PBR> CourseList = FXCollections.observableArrayList();
	
	@Override
	public void initialize(URL location,ResourceBundle resources){
		this.userTeller = Main.getUser();
		this.EmailtNo = Main.getEmailNo();
		t1.setCellValueFactory(new PropertyValueFactory<PBR,String>("books"));
		try{
		if(userTeller==0){
			int counter = ((AdminProfile)Main.getAdmProfs().getAdminData().get(EmailtNo)).getBookedrooms().size();
			for(int i = 0 ; i < counter ; i++){
				CourseList.add(new PBR((String)(((AdminProfile)Main.getAdmProfs().getAdminData().get(EmailtNo)).getBookedrooms().get(i))));
			}
		}
		else if(userTeller == 1){
			int counter = ((StudentProfile)Main.getStuProfs().getStudentData().get(EmailtNo)).getBookedrooms().size();
			for(int i = 0 ; i < counter ; i++){
				CourseList.add(new PBR((String)(((StudentProfile)Main.getStuProfs().getStudentData().get(EmailtNo)).getBookedrooms().get(i))));
			}
		}
		else{
			int counter = ((FacultyProfile)Main.getFacProfs().getFacultyData().get(EmailtNo)).getBookedrooms().size();
			for(int i = 0 ; i < counter ; i++){
				CourseList.add(new PBR((String)(((FacultyProfile)Main.getFacProfs().getFacultyData().get(EmailtNo)).getBookedrooms().get(i))));
			}
		}
		}
		catch(Exception e){
			
		}
		table.setItems(CourseList);
	}
	public void StudentTeller(int no,int user){
		this.EmailtNo = no;
		this.userTeller = user;
	}
}
