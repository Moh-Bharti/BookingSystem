package application;


public class PBR {
	private String books;
	PBR(String giv){
		books = giv;
	}
	public String getBooks() {
		return books;
	}
	public void setBooks(String books) {
		this.books = books;
	}
	
}
