package application;
import java.io.FileNotFoundException;
import java.io.IOException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
public class S_Req_Controller {
	@FXML
	private Button b1;
	@FXML
	private Button b2;
	@FXML
	private Button b3;
	@FXML
	private Button b4;
	@FXML
	private Button b5;
	@FXML
	private Button b6;
	@FXML
	private Button b7;
	@FXML
	private Button b8;
	@FXML
	private Label l1;
	@FXML
	private TextField t1;
	@FXML
	private TextField t2;
	@FXML
	private TextField t3;
	@FXML
	private TextField t4;
	private int EmailNo;
	public void SubReq(ActionEvent event) throws IOException,FileNotFoundException{
		this.EmailNo = Main.getEmailNo();
		((Main.getRoomRequests()).getRequests()).add(new RoomRequest(EmailNo, t1.getText(), t2.getText(), t3.getText(), t4.getText()));
		String ad = t2.getText()+"&"+t3.getText()+"-"+t4.getText()+"_"+t1.getText();
		((StudentProfile)(Main.getStuProfs().getStudentData().get(EmailNo))).getReqs().add(ad);
		Main.Save();
	}
	public void start(int Eno){
		this.EmailNo = Eno;
	}
	public void CanReq(ActionEvent event) throws IOException,FileNotFoundException{
		this.EmailNo = Main.getEmailNo();
		String ad = t2.getText()+"&"+t3.getText()+"-"+t4.getText()+"_"+t1.getText();
		((StudentProfile)(Main.getStuProfs().getStudentData().get(EmailNo))).getReqs().remove(ad);
		int counter = ((Main.getRoomRequests()).getRequests()).size();
		for(int i = 0 ; i< counter ; i++){
			RoomRequest curr = ((RoomRequest)(((Main.getRoomRequests()).getRequests()).get(i)));
			if(curr.net().equals(ad)){
				((Main.getRoomRequests()).getRequests()).remove(curr);
				return;
			}
		}

		Main.Save();
		
	}
	public void CanBook(ActionEvent event) throws IOException,FileNotFoundException{
		this.EmailNo = Main.getEmailNo();
		String ad = t2.getText()+"&"+t3.getText()+"-"+t4.getText()+"_"+t1.getText();
		
		Main.getAllRooms().TimingRoomRemove(t2.getText(), t1.getText(), t3.getText(), t4.getText());
		
		((StudentProfile)(Main.getStuProfs().getStudentData().get(EmailNo))).getBookedrooms().remove(ad);
		Main.Save();
		
		
	}
}
