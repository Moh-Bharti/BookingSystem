package application;
import java.io.FileNotFoundException;
import java.io.IOException;

import javafx.event.ActionEvent;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class StudentController {
	private int EmailNo;
	@FXML
	private Button b1;
	@FXML
	private Button b2;
	@FXML
	private Button b3;
	@FXML
	private Button b4;
	@FXML
	private Button b5;
	@FXML
	private Button b6;
	@FXML
	private Button b7;
	@FXML
	private Button b8;
	@FXML
	private Button b9;
	@FXML
	private Button b10;
	@FXML
	private Button b11;
	@FXML
	private Button b12;
	@FXML
	private Label l1;
	@FXML
	private TextField t1;
	@FXML
	private TextField t2;
	@FXML
	private TextField t3;

	public void start(String head,int no){
		l1.setText(head);
		this.EmailNo = no;
	}

	public void SignOut(ActionEvent event){
		Stage primaryStage = new Stage();
		try {
			Parent root = FXMLLoader.load(getClass().getResource("/application/Open.fxml"));
			Scene scene = new Scene(root,600,600);
			scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			primaryStage.setScene(scene);
			primaryStage.show();
			((Node) (event.getSource())).getScene().getWindow().hide();
		}
		catch(Exception e) {
		e.printStackTrace();
		}
	}
	public void ViewAllCourses(ActionEvent event){
		Stage primaryStage = new Stage();
		try {
			Parent root = FXMLLoader.load(getClass().getResource("/application/AllCourses.fxml"));
			Scene scene = new Scene(root,600,600);
			scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			primaryStage.setScene(scene);
			primaryStage.show();
		}
		catch(Exception e) {
		e.printStackTrace();
		}
	}
	public void ViewPersonalCourses(ActionEvent event){
		Stage primaryStage = new Stage();
		try {
		FXMLLoader loader = new FXMLLoader(getClass().getResource("/application/CoursePage.fxml"));
		
		//Parent root = FXMLLoader.load(getClass().getResource("/application/Faculty.fxml"));
		Scene scene = new Scene(loader.load(),600,600);
		//Scene scene = new Scene(root,600,600);
		scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
		primaryStage.setScene(scene);
		CoursePageController controller = loader.<CoursePageController>getController();
		controller.StudentTeller(EmailNo);
				
		primaryStage.show();
	} catch(Exception e) {
		e.printStackTrace();
	}
	}
	public void Add(ActionEvent event) throws IOException,FileNotFoundException{
			String courseAcro = t2.getText();
			((StudentProfile)Main.getStuProfs().getStudentData().get(EmailNo)).add(courseAcro);
			Main.Save();
		}
	public void Remove(ActionEvent event)  throws IOException,FileNotFoundException{
			String courseAcro = t2.getText();
			((StudentProfile)Main.getStuProfs().getStudentData().get(EmailNo)).delete(courseAcro);
			Main.Save();
			
		}
	public void Search(ActionEvent event){
		Main.setStudentSearch(t3.getText());
		Stage primaryStage = new Stage();
		try {
		FXMLLoader loader = new FXMLLoader(getClass().getResource("/application/CourseSearchPage.fxml"));
		//Parent root = FXMLLoader.load(getClass().getResource("/application/Faculty.fxml"));
		Scene scene = new Scene(loader.load(),600,600);
		//Scene scene = new Scene(root,600,600);
		scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
		primaryStage.setScene(scene);
				
		primaryStage.show();
	} catch(Exception e) {
		e.printStackTrace();
	}
	}
}
