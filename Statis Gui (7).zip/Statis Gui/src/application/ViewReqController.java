package application;

import java.net.URL;
import java.util.ResourceBundle;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

public class ViewReqController implements Initializable {
	@FXML
	private TableView<PBR> table;
	@FXML
	private TableColumn<PBR,String> t1;
	private int EmailtNo;
	private int userTeller;
	
public ObservableList<PBR> CourseList = FXCollections.observableArrayList();
	
	@Override
	public void initialize(URL location,ResourceBundle resources){
		t1.setCellValueFactory(new PropertyValueFactory<PBR,String>("books"));
			this.userTeller = Main.getUser();
			this.EmailtNo = Main.getEmailNo();
			try{
			if(userTeller == 0){
				int counter = Main.getRoomRequests().getRequests().size();
				for(int i = 0 ; i < counter ; i++){
					String ad = ((RoomRequest)(Main.getRoomRequests().getRequests().get(i))).net();
				
					CourseList.add(new PBR(ad));
				}
			}
			else{
				int counter = ((StudentProfile)(Main.getStuProfs().getStudentData().get(EmailtNo))).getReqs().size();
				for(int i = 0 ; i < counter ; i++){
					String ad = ((String)((((StudentProfile)(Main.getStuProfs().getStudentData().get(EmailtNo))).getReqs()).get(i)));
					CourseList.add(new PBR(ad));
				}
			}

			}
			catch(Exception e){
				
			}
		table.setItems(CourseList);
	}
}
