package application;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
public class AdminController {
	private int EmailNo;
	@FXML
	private Button b1;
	@FXML
	private Button b2;
	@FXML
	private Button b3;
	@FXML
	private Button b4;
	@FXML
	private Button b5;
	@FXML
	private Button b6;
	@FXML
	private Button b7;
	@FXML
	private Button b8;
	@FXML
	private Button b9;
	@FXML
	private Button b10;
	@FXML
	private Button b11;
	@FXML
	private Label l1;
	@FXML
	private TextField t1;
	public void start(String head,int no){
		l1.setText(head);
		this.EmailNo = no;
	}
	public void ViewAllCourses(ActionEvent event){
		Stage primaryStage = new Stage();
		try {
			Parent root = FXMLLoader.load(getClass().getResource("/application/AllCourses.fxml"));
			Scene scene = new Scene(root,600,600);
			scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			primaryStage.setScene(scene);
			primaryStage.show();
		}
		catch(Exception e) {
		e.printStackTrace();
		}
	}
	public void SignOut(ActionEvent event){
		Stage primaryStage = new Stage();
		try {
			Parent root = FXMLLoader.load(getClass().getResource("/application/Open.fxml"));
			Scene scene = new Scene(root,600,600);
			scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			primaryStage.setScene(scene);
			primaryStage.show();
			((Node) (event.getSource())).getScene().getWindow().hide();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	public void BookRoom(ActionEvent event){
		Stage primaryStage = new Stage();
		try {
		FXMLLoader loader = new FXMLLoader(getClass().getResource("/application/BookRoom.fxml"));
		
		//Parent root = FXMLLoader.load(getClass().getResource("/application/Faculty.fxml"));
		Scene scene = new Scene(loader.load(),600,600);
		//Scene scene = new Scene(root,600,600);
		scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
		primaryStage.setScene(scene);
		BookRoomController controller = loader.<BookRoomController>getController();
		controller.start(EmailNo);
				
		primaryStage.show();
	} catch(Exception e) {
		e.printStackTrace();
	}
	}
	public void roomStatus(ActionEvent event){
		Stage primaryStage = new Stage();
		try {
		
		
		Parent root = FXMLLoader.load(getClass().getResource("/application/RoomTable.fxml"));
		Scene scene = new Scene(root,600,600);
		scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
		primaryStage.setScene(scene);
				
		primaryStage.show();
		}
		catch(Exception e){
			
		}
	}
	public void PersonalBookings(ActionEvent event){
		Stage primaryStage = new Stage();
		try {
		FXMLLoader loader = new FXMLLoader(getClass().getResource("/application/PersonalBookedRoom.fxml"));
		
		//Parent root = FXMLLoader.load(getClass().getResource("/application/Faculty.fxml"));
		Scene scene = new Scene(loader.load(),600,600);
		//Scene scene = new Scene(root,600,600);
		scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
		primaryStage.setScene(scene);
		PersonalBookedRoomController controller = loader.<PersonalBookedRoomController>getController();
		controller.StudentTeller(EmailNo,0);
				
		primaryStage.show();
	} catch(Exception e) {
		e.printStackTrace();
	}
	}
	public void ViewReq(ActionEvent event){
		Stage primaryStage = new Stage();
		try {
		Parent root = FXMLLoader.load(getClass().getResource("/application/ViewReq.fxml"));
		Scene scene = new Scene(root,600,600);
		scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
		primaryStage.setScene(scene);
				
		primaryStage.show();
		}
		catch(Exception e){
			
		}
		
	}
	public void ActionOnReq(ActionEvent event){
		Stage primaryStage = new Stage();
		try {
		Parent root = FXMLLoader.load(getClass().getResource("/application/ActionOnReq.fxml"));
		Scene scene = new Scene(root,600,600);
		scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
		primaryStage.setScene(scene);
				
		primaryStage.show();
		}
		catch(Exception e){
			
		}
	}
	public void ViewTimeTable(ActionEvent event){
		Stage primaryStage = new Stage();
		try {
		
		
		Parent root = FXMLLoader.load(getClass().getResource("/application/CourseTimeTable.fxml"));
		Scene scene = new Scene(root,600,600);
		scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
		primaryStage.setScene(scene);
				
		primaryStage.show();
		}
		catch(Exception e){
			
		}
	}
}
