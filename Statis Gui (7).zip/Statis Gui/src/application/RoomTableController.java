package application;

import java.net.URL;
import java.util.ResourceBundle;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

public class RoomTableController implements Initializable {
	@FXML
	private TableView<RoomTab> table;
	@FXML
	private TableColumn<RoomTab,String> t1;
	@FXML
	private TableColumn<RoomTab,String> t2;
	@FXML
	private TableColumn<RoomTab,String> t3;
	@FXML
	private TableColumn<RoomTab,String> t4;
	@FXML
	private TableColumn<RoomTab,String> t5;
	@FXML
	private TableColumn<RoomTab,String> t6;
	@FXML
	private TableColumn<RoomTab,String> t7;
	@FXML
	private TableColumn<RoomTab,String> t8;
	@FXML
	private TableColumn<RoomTab,String> t9;
	@FXML
	private TableColumn<RoomTab,String> t10;
	@FXML
	private TableColumn<RoomTab,String> t11;
	@FXML
	private TableColumn<RoomTab,String> t12;
	@FXML
	private TableColumn<RoomTab,String> t13;
	@FXML
	private TableColumn<RoomTab,String> t14;
	@FXML
	private TableColumn<RoomTab,String> t15;
	@FXML
	private TableColumn<RoomTab,String> t16;
	@FXML
	private TableColumn<RoomTab,String> t17;
	@FXML
	private TableColumn<RoomTab,String> t18;
	
	public ObservableList<RoomTab> CourseList = FXCollections.observableArrayList();
	@Override
	public void initialize(URL location,ResourceBundle resources){
		t1.setCellValueFactory(new PropertyValueFactory<RoomTab,String>("t1"));
		t2.setCellValueFactory(new PropertyValueFactory<RoomTab,String>("t2"));
		t3.setCellValueFactory(new PropertyValueFactory<RoomTab,String>("t3"));
		t4.setCellValueFactory(new PropertyValueFactory<RoomTab,String>("t4"));
		t5.setCellValueFactory(new PropertyValueFactory<RoomTab,String>("t5"));
		t6.setCellValueFactory(new PropertyValueFactory<RoomTab,String>("t6"));
		t7.setCellValueFactory(new PropertyValueFactory<RoomTab,String>("t7"));
		t8.setCellValueFactory(new PropertyValueFactory<RoomTab,String>("t8"));
		t9.setCellValueFactory(new PropertyValueFactory<RoomTab,String>("t9"));
		t10.setCellValueFactory(new PropertyValueFactory<RoomTab,String>("t10"));
		t11.setCellValueFactory(new PropertyValueFactory<RoomTab,String>("t11"));
		t12.setCellValueFactory(new PropertyValueFactory<RoomTab,String>("t12"));
		t13.setCellValueFactory(new PropertyValueFactory<RoomTab,String>("t13"));
		t14.setCellValueFactory(new PropertyValueFactory<RoomTab,String>("t14"));
		t15.setCellValueFactory(new PropertyValueFactory<RoomTab,String>("t15"));
		t16.setCellValueFactory(new PropertyValueFactory<RoomTab,String>("t16"));
		t17.setCellValueFactory(new PropertyValueFactory<RoomTab,String>("t17"));
		t18.setCellValueFactory(new PropertyValueFactory<RoomTab,String>("t18"));
		int counter = Main.getAllRooms().getRooms().size();
		String[][] Rt = new String[5][17];
		for(int i = 0 ; i<5;i++){
			for(int j = 0 ; j <17;j++){
				Rt[i][j] = "";
			}
		}
		for(int i = 0 ; i <counter ; i++){
			for(int day = 0 ; day<5;day++){
				for(int j = 0 ; j < 17 ;j++){
					int f = ((Room)(Main.getAllRooms().getRooms().get(i))).getRoomTimings()[day][j];
					if(f==1){
						Rt[day][j] =Rt[day][j]+" "+ ((Room)(Main.getAllRooms().getRooms().get(i))).getRoomNo();
					}
				}
			}
		}
		for(int i = 0 ; i < 5 ; i++){
			if(i==0){
				CourseList.add(new RoomTab("Monday",Rt[i][0],Rt[i][1],Rt[i][2],Rt[i][3],Rt[i][4],Rt[i][5],Rt[i][6],Rt[i][7],Rt[i][8],Rt[i][9],Rt[i][10],Rt[i][11],Rt[i][12],Rt[i][13],Rt[i][14],Rt[i][15],Rt[i][16]));	
			}
			else if(i==1){
				CourseList.add(new RoomTab("Tuesday",Rt[i][0],Rt[i][1],Rt[i][2],Rt[i][3],Rt[i][4],Rt[i][5],Rt[i][6],Rt[i][7],Rt[i][8],Rt[i][9],Rt[i][10],Rt[i][11],Rt[i][12],Rt[i][13],Rt[i][14],Rt[i][15],Rt[i][16]));	
			}
			else if(i==2){
				CourseList.add(new RoomTab("Wednesday",Rt[i][0],Rt[i][1],Rt[i][2],Rt[i][3],Rt[i][4],Rt[i][5],Rt[i][6],Rt[i][7],Rt[i][8],Rt[i][9],Rt[i][10],Rt[i][11],Rt[i][12],Rt[i][13],Rt[i][14],Rt[i][15],Rt[i][16]));	
			}
			else if(i==3){
				CourseList.add(new RoomTab("Thursday",Rt[i][0],Rt[i][1],Rt[i][2],Rt[i][3],Rt[i][4],Rt[i][5],Rt[i][6],Rt[i][7],Rt[i][8],Rt[i][9],Rt[i][10],Rt[i][11],Rt[i][12],Rt[i][13],Rt[i][14],Rt[i][15],Rt[i][16]));	
			}
			else{
				CourseList.add(new RoomTab("Friday",Rt[i][0],Rt[i][1],Rt[i][2],Rt[i][3],Rt[i][4],Rt[i][5],Rt[i][6],Rt[i][7],Rt[i][8],Rt[i][9],Rt[i][10],Rt[i][11],Rt[i][12],Rt[i][13],Rt[i][14],Rt[i][15],Rt[i][16]));	
			}
		}
		table.setItems(CourseList);
		
	}
}
