package application;

import java.io.FileNotFoundException;
import java.io.IOException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
public class BookRoomController {
	@FXML
	private Button b1;
	@FXML
	private Button b2;
	@FXML
	private Button b3;
	@FXML
	private Button b4;
	@FXML
	private Button b5;
	@FXML
	private Button b6;
	@FXML
	private Button b7;
	@FXML
	private Button b8;
	@FXML
	private Label l1;
	@FXML
	private TextField t1;
	@FXML
	private TextField t2;
	@FXML
	private TextField t3;
	@FXML
	private TextField t4;
	private int EmailNo;
	public void start(int no){
		this.EmailNo = no;
	}
	
	public void Book(ActionEvent event) throws IOException,FileNotFoundException{
		String searcher = t3.getText()+"-"+t4.getText()+"_"+t1.getText();
		String day = t2.getText();
		if(day.equals("Monday")){
			try{
				Main.getAllRooms().TimingRoomAdd(0,searcher);
			}
			catch(Exception e){
				
			}
		}
		else if(day.equals("Tuesday")){
			try{
				Main.getAllRooms().TimingRoomAdd(1,searcher);
			}
			catch(Exception e){
				
			}
		}
		else if(day.equals("Wednesday")){
			try{
				Main.getAllRooms().TimingRoomAdd(2,searcher);
			}
			catch(Exception e){
				
			}
		}
		else if(day.equals("Thursday")){
			try{
				Main.getAllRooms().TimingRoomAdd(3,searcher);
			}
			catch(Exception e){
				
			}
		}
		else{
			try{
				Main.getAllRooms().TimingRoomAdd(4,searcher);
			}
			catch(Exception e){
				
			}
		}
		String ad =day+"&"+searcher;
		((AdminProfile)(Main.getAdmProfs().getAdminData().get(EmailNo))).getBookedrooms().add(ad);
		Main.Save();
	}
	
	public void cancel(ActionEvent event) throws IOException,FileNotFoundException{
		String searcher = t3.getText()+"-"+t4.getText()+"_"+t1.getText();
		String day = t2.getText();
		String ad =day+"&"+searcher;
		int counter = ((FacultyProfile)(Main.getFacProfs().getFacultyData().get(EmailNo))).getBookedrooms().size();
		for(int i = 0 ; i<counter;i++){
			if(((String)(((StudentProfile)(Main.getStuProfs().getStudentData().get(EmailNo))).getBookedrooms().get(i))).equals(ad)){
				
				Main.getAllRooms().TimingRoomRemove(day, t1.getText(), t3.getText(), t4.getText());
				((StudentProfile)(Main.getStuProfs().getStudentData().get(EmailNo))).getBookedrooms().remove(ad);
				Main.Save();	
				return;
			}

		}
	}
	
}
