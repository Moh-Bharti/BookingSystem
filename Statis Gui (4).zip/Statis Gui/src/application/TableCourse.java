package application;

import java.io.Serializable;

import javafx.beans.property.SimpleStringProperty;

public class TableCourse implements Serializable{
		private final SimpleStringProperty MandatoryORElective;
		private final SimpleStringProperty Name;
		private final SimpleStringProperty CourseCode;
		private final SimpleStringProperty Credits;
		private final SimpleStringProperty Acronym;
		private final SimpleStringProperty Mon;
		private final SimpleStringProperty Tue;
		private final SimpleStringProperty Wed;
		private final SimpleStringProperty Thur;
		private final SimpleStringProperty Fri;
		private final SimpleStringProperty Tut;
		private final SimpleStringProperty Lab;
		private final SimpleStringProperty preConditions;
		private final SimpleStringProperty postConditions;
		private final SimpleStringProperty Instructor;
		
		public TableCourse(String typ,String CN,String CC,String instr,String Cred,String Acrym,String M,String T,String W,String Th,String F,String tut,String lab,String pre,String post) {
			this.MandatoryORElective = new SimpleStringProperty(typ);
			this.Name = new SimpleStringProperty(CN);
			this.CourseCode = new SimpleStringProperty(CC);
			this.Instructor = new SimpleStringProperty(instr);
			this.Credits = new SimpleStringProperty(Cred);
			this.Acronym = new SimpleStringProperty(Acrym);
			this.Mon = new SimpleStringProperty(M);
			this.Tue = new SimpleStringProperty(T);
			this.Wed = new SimpleStringProperty(W);
			this.Thur = new SimpleStringProperty(Th);
			this.Fri = new SimpleStringProperty(F);
			this.Lab = new SimpleStringProperty(lab);
			this.Tut = new SimpleStringProperty(tut);
			this.preConditions = new SimpleStringProperty(pre);
			this.postConditions = new SimpleStringProperty(post);
		}
		public String getCourseType() {
			return MandatoryORElective.get();
		}
		public String getCourseName() {
			return Name.get();
		}
		public void setCourseName(String courseName) {
			Name.set(courseName);
		}
		public String getCourseCode() {
			return CourseCode.get();
		}
		public void setCourseCode(String courseCode) {
			CourseCode.set(courseCode);
		}
		public String getPreConditions() {
			return preConditions.get();
		}
		public void setPreConditions(String preConditions) {
			this.preConditions.set(preConditions);
		}
		public String getPostConditions() {
			return postConditions.get();
		}




		public String getAcronym() {
			return Acronym.get();
		}
		public String getCredits() {
			return Credits.get();
		}

		public String getMon() {
			return Mon.get();
		}

		public String getTue() {
			return Tue.get();
		}

		public String getWed() {
			return Wed.get();
		}

		public String getThur() {
			return Thur.get();
		}

		public String getFri() {
			return Fri.get();
		}
		
		public String getTut() {
			return Tut.get();
		}

		public String getLab() {
			return Lab.get();
		}

		public String getInstructor() {
			return Instructor.get();
		}

			
	
}
