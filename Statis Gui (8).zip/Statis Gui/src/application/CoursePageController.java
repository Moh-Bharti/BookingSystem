package application;

import java.net.URL;
import java.util.ResourceBundle;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
public class CoursePageController implements Initializable {
	private int studentNo;
	@FXML
	private TableView<TableCourse> table;
	@FXML
	private TableColumn<TableCourse,String> MandatoryORElective;
	@FXML
	private TableColumn<TableCourse,String> Name;
	@FXML
	private TableColumn<TableCourse,String> Code;
	@FXML
	private TableColumn<TableCourse,String> Instructer;
	@FXML
	private TableColumn<TableCourse,String> Credits;
	@FXML
	private TableColumn<TableCourse,String> Acronym;
	@FXML
	private TableColumn<TableCourse,String> t7;
	@FXML
	private TableColumn<TableCourse,String> t8;
	@FXML
	private TableColumn<TableCourse,String> t9;
	@FXML
	private TableColumn<TableCourse,String> t10;
	@FXML
	private TableColumn<TableCourse,String> t11;
	@FXML
	private TableColumn<TableCourse,String> t12;
	@FXML
	private TableColumn<TableCourse,String> t13;
	@FXML
	private TableColumn<TableCourse,String> t14;
	@FXML
	private TableColumn<TableCourse,String> t15;
	
	public ObservableList<TableCourse> CourseList = FXCollections.observableArrayList();
	@Override
	public void initialize(URL location,ResourceBundle resources){
		this.studentNo = Main.getEmailNo();
		MandatoryORElective.setCellValueFactory(new PropertyValueFactory<TableCourse,String>("CourseType"));
		Name.setCellValueFactory(new PropertyValueFactory<TableCourse,String>("CourseName"));
		Code.setCellValueFactory(new PropertyValueFactory<TableCourse,String>("CourseCode"));
		Instructer.setCellValueFactory(new PropertyValueFactory<TableCourse,String>("Instructor"));
		Credits.setCellValueFactory(new PropertyValueFactory<TableCourse,String>("Credits"));
		Acronym.setCellValueFactory(new PropertyValueFactory<TableCourse,String>("Acronym"));
		t7.setCellValueFactory(new PropertyValueFactory<TableCourse,String>("Mon"));
		t8.setCellValueFactory(new PropertyValueFactory<TableCourse,String>("Tue"));
		t9.setCellValueFactory(new PropertyValueFactory<TableCourse,String>("Wed"));
		t10.setCellValueFactory(new PropertyValueFactory<TableCourse,String>("Thur"));
		t11.setCellValueFactory(new PropertyValueFactory<TableCourse,String>("Fri"));
		t12.setCellValueFactory(new PropertyValueFactory<TableCourse,String>("Tut"));
		t13.setCellValueFactory(new PropertyValueFactory<TableCourse,String>("Lab"));
		t14.setCellValueFactory(new PropertyValueFactory<TableCourse,String>("PreConditions"));
		t15.setCellValueFactory(new PropertyValueFactory<TableCourse,String>("PostConditions"));
		int counter = ((StudentProfile)Main.getStuProfs().getStudentData().get(studentNo)).getCourses().size();
		
		for(int i = 0 ; i < counter ; i++){
			CourseList.add(new TableCourse(((courses)(((StudentProfile)Main.getStuProfs().getStudentData().get(studentNo)).getCourses().get(i))).getCourseType(),((courses)(((StudentProfile)Main.getStuProfs().getStudentData().get(studentNo)).getCourses().get(i))).getCourseName(),((courses)(((StudentProfile)Main.getStuProfs().getStudentData().get(studentNo)).getCourses().get(i))).getCourseCode(),((courses)(((StudentProfile)Main.getStuProfs().getStudentData().get(studentNo)).getCourses().get(i))).getInstructor(),((courses)(((StudentProfile)Main.getStuProfs().getStudentData().get(studentNo)).getCourses().get(i))).getCredits(),((courses)(((StudentProfile)Main.getStuProfs().getStudentData().get(studentNo)).getCourses().get(i))).getAcronym(),((courses)(((StudentProfile)Main.getStuProfs().getStudentData().get(studentNo)).getCourses().get(i))).getMon(),((courses)(((StudentProfile)Main.getStuProfs().getStudentData().get(studentNo)).getCourses().get(i))).getTue(),((courses)(((StudentProfile)Main.getStuProfs().getStudentData().get(studentNo)).getCourses().get(i))).getWed(),((courses)(((StudentProfile)Main.getStuProfs().getStudentData().get(studentNo)).getCourses().get(i))).getThur(),((courses)(((StudentProfile)Main.getStuProfs().getStudentData().get(studentNo)).getCourses().get(i))).getFri(),((courses)(((StudentProfile)Main.getStuProfs().getStudentData().get(studentNo)).getCourses().get(i))).getTut(),((courses)(((StudentProfile)Main.getStuProfs().getStudentData().get(studentNo)).getCourses().get(i))).getLab(),((courses)(((StudentProfile)Main.getStuProfs().getStudentData().get(studentNo)).getCourses().get(i))).getPreConditions(),((courses)(((StudentProfile)Main.getStuProfs().getStudentData().get(studentNo)).getCourses().get(i))).getPostConditions()));
		}
		table.setItems(CourseList);
		
	}
	public void StudentTeller(int no){
		this.studentNo = no;
	}

}
