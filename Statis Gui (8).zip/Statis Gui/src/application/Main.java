package application;
	
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.stage.Stage;
import javafx.scene.Parent;
import javafx.scene.Scene;



public class Main extends Application {
	public static StudentEmails StuEmails;
	public static AdminEmails AdmEmails;
	public static FacultyEmails FacEmails;
	public static TimeTable MainTimeTable;
	public static FacultyDataBase FacProfs;
	public static AdminDataBase AdmProfs;
	public static StudentDataBase StuProfs;
	public static String StudentSearch;
	public static AllRoom AllRooms;
	public static RoomRequestDataBase RoomRequests;
	public static int user;
	public static int EmailNo;
	
	
	
	
	public static int getUser() {
		return user;
	}



	public static void setUser(int user) {
		Main.user = user;
	}



	public static int getEmailNo() {
		return EmailNo;
	}



	public static void setEmailNo(int emailNo) {
		EmailNo = emailNo;
	}



	public static void Save()throws IOException,FileNotFoundException{
		FacEmailsSerialize("FEmails", FacEmails);
		StuEmailsSerialize("SEmails", StuEmails);
		AdmEmailsSerialize("AEmails", AdmEmails);
		FacDataSerialize("FData", FacProfs);
		StuDataSerialize("SData", StuProfs);
		AdmDataSerialize("AData", AdmProfs);
		AllRoomDataSerialize("AllRoomData", AllRooms);
		RoomRequestDataSerialize("ReqData", RoomRequests);
	}
	
	
	
	@Override
	public void start(Stage primaryStage) {
		try {
			Parent root = FXMLLoader.load(getClass().getResource("/application/Open.fxml"));
			Scene scene = new Scene(root,600,600);
			scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			primaryStage.setScene(scene);
			primaryStage.show();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) throws IOException,ClassNotFoundException {
		/*StudentEmails StuEmails = new StudentEmails();
		StuEmails.addEmail("student1@iiitd.ac.in");
		StuEmails.addEmail("student2@iiitd.ac.in");
		StuEmails.addEmail("student3@iiitd.ac.in");
		StuEmails.addEmail("student4@iiitd.ac.in");
		StuEmails.addEmail("student5@iiitd.ac.in");
		StuEmailsSerialize("SEmails", StuEmails);
		AdminEmails AdmEmails = new AdminEmails();
		AdmEmails.addEmail("admin1@iiitd.ac.in");
		AdmEmails.addEmail("admin2@iiitd.ac.in");
		AdmEmails.addEmail("admin3@iiitd.ac.in");
		AdmEmails.addEmail("admin4@iiitd.ac.in");
		AdmEmails.addEmail("admin5@iiitd.ac.in");
		AdmEmailsSerialize("AEmails", AdmEmails);
		FacultyEmails FacEmails = new FacultyEmails();
		FacEmails.addEmail("faculty1@iiitd.ac.in");
		FacEmails.addEmail("faculty2@iiitd.ac.in");
		FacEmails.addEmail("faculty3@iiitd.ac.in");
		FacEmails.addEmail("faculty4@iiitd.ac.in");
		FacEmails.addEmail("faculty5@iiitd.ac.in");
		FacEmailsSerialize("FEmails", FacEmails);
		FacProfs = new FacultyDataBase();
		FacDataSerialize("FData", FacProfs);
		StuProfs = new StudentDataBase();
		StuDataSerialize("SData", StuProfs);
		AdmProfs = new AdminDataBase();
		AdmDataSerialize("AData", AdmProfs);
		AllRooms = new AllRoom();
		AllRooms.getRooms().add(new Room("C01",150));
		AllRooms.getRooms().add(new Room("C02",50));
		AllRooms.getRooms().add(new Room("C03",50));
		AllRooms.getRooms().add(new Room("C11",150));
		AllRooms.getRooms().add(new Room("C12",50));
		AllRooms.getRooms().add(new Room("C13",50));
		AllRooms.getRooms().add(new Room("C21",150));
		AllRooms.getRooms().add(new Room("C22",50));
		AllRooms.getRooms().add(new Room("C23",50));
		AllRooms.getRooms().add(new Room("C24",150));
		AllRooms.getRooms().add(new Room("LR1",40));
		AllRooms.getRooms().add(new Room("LR2",40));
		AllRooms.getRooms().add(new Room("LR3",30));
		AllRooms.getRooms().add(new Room("S01",70));
		AllRooms.getRooms().add(new Room("S02",70));
		AllRoomDataSerialize("AllRoomData", AllRooms);
		RoomRequests = new RoomRequestDataBase();*/
		
		AllRooms = AllRoomDataDeserialize("AllRoomData");
		StuEmails = StuEmailsDeserialize("SEMails");
		AdmEmails = AdmEmailsDeserialize("AEMails");
		FacEmails = FacEmailsDeserialize("FEMails");
		try{
			FacProfs = FacDataDeserialize("FData");
		}
		catch(Exception e){
			FacProfs = new FacultyDataBase();
		}
		try{
			StuProfs = StuDataDeserialize("SData");
		}
		catch(Exception e){
			StuProfs = new StudentDataBase();
		}
		try{
			AdmProfs = AdmDataDeserialize("AData");
		}
		catch(Exception e){
			AdmProfs = new AdminDataBase();
		}
		try{
			RoomRequests = RoomRequestDataDeserialize("ReqData");
		}
		catch(Exception e){
			RoomRequests = new RoomRequestDataBase();
		}
		String CoursesDataRead = "C:\\Users\\AJAY KUMAR\\workspace\\Statis Gui\\src\\application\\ReadCourseData.csv";
		String line = "";
		String delimeter = ",";
		MainTimeTable = new TimeTable();
		try(BufferedReader br = new BufferedReader(new FileReader(CoursesDataRead))){
			int counter = 0;
			while((line=br.readLine())!=null){
			if(counter==0){
				counter++;
			}
			else{
				String[] c = line.split(delimeter);
				if(c.length<2){
					
				}
				else{
					MainTimeTable.getCourseData().add(new courses(c[0],c[1],c[2],c[3],c[4],c[5],c[6],c[7],c[8],c[8],c[10],c[11],c[12],c[13],c[14]));
					try{
						AllRooms.TimingRoomAdd(0,c[7]);
						
					}
					catch(Exception e){
						
					}
					try{
						AllRooms.TimingCourseAdd(0, c[7], c[5]); 
					}
					catch(Exception e){
						
					}
					try{
						AllRooms.TimingRoomAdd(1,c[8]);
					}
					catch(Exception e){
						
					}
					try{
						AllRooms.TimingCourseAdd(1, c[8], c[5]); 
					}
					catch(Exception e){
						
					}
					try{
						AllRooms.TimingRoomAdd(2,c[9]);
					}
					catch(Exception e){
						
					}
					try{
						AllRooms.TimingCourseAdd(2, c[9], c[5]); 
					}
					catch(Exception e){
						
					}
					try{
						AllRooms.TimingRoomAdd(3,c[10]);
					}
					catch(Exception e){
						
					}
					try{
						AllRooms.TimingCourseAdd(3, c[10], c[5]); 
					}
					catch(Exception e){
						
					}
					try{
						AllRooms.TimingRoomAdd(4,c[11]);
					}
					catch(Exception e){
						
					}
					try{
						AllRooms.TimingCourseAdd(4, c[11], c[5]); 
					}
					catch(Exception e){
						
					}
					
					
				}
				//String S = c[0]+","+c[1]+","+c[2]+","+c[3]+","+c[4]+","+c[5]+","+c[6]+","+c[7]+","+c[8]+","+c[9]+","+c[10]+c[11]+","+c[12]+","+c[13]+","+c[14];

				counter++;
				}
			}
		}
		catch(Exception e){
			System.out.println(e.getMessage());
		}
		
		/*System.out.println("working");
		if(StuEmails.search("student4@iiitd.ac.in")==true){
			System.out.println("dzvfzsdfhsdjkflzdskhfakjsdhing");
		}*/
		launch(args);
	}
	public static StudentEmails StuEmailsDeserialize(String SEmails) throws IOException,ClassNotFoundException{
		ObjectInputStream in = null;
		try{
			in = new ObjectInputStream( new FileInputStream("C:\\Users\\AJAY KUMAR\\workspace\\Statis Gui\\src\\application\\"+SEmails+".txt"));
			return (StudentEmails) in.readObject();
		}
		finally{
			in.close();
		}
	}
	public static void StuEmailsSerialize(String SEmails,StudentEmails PSerialize)throws IOException{
		ObjectOutputStream out = null;
		try{
			out = new ObjectOutputStream(new FileOutputStream("C:\\Users\\AJAY KUMAR\\workspace\\Statis Gui\\src\\application\\"+SEmails+".txt"));
			out.writeObject(PSerialize);
		}
		finally{
			out.close();
		}
		
		
	}
	
	public static StudentDataBase StuDataDeserialize(String SData) throws IOException,ClassNotFoundException{
		ObjectInputStream in = null;
		try{
			in = new ObjectInputStream( new FileInputStream("C:\\Users\\AJAY KUMAR\\workspace\\Statis Gui\\src\\application\\"+SData+".txt"));
			return (StudentDataBase) in.readObject();
		}
		finally{
			in.close();
		}
	}
	public static void StuDataSerialize(String SData,StudentDataBase PSerialize)throws IOException{
		ObjectOutputStream out = null;
		try{
			out = new ObjectOutputStream(new FileOutputStream("C:\\Users\\AJAY KUMAR\\workspace\\Statis Gui\\src\\application\\"+SData+".txt"));
			out.writeObject(PSerialize);
		}
		finally{
			out.close();
		}
		
		
	}
	
	public static StudentEmails getStuEmails() {
		return StuEmails;
	}

	public static void setStuEmails(StudentEmails stuEmails) {
		StuEmails = stuEmails;
	}
	
	

	public static StudentDataBase getStuProfs() {
		return StuProfs;
	}



	public static void setStuProfs(StudentDataBase stuProfs) {
		StuProfs = stuProfs;
	}



	public static AdminEmails AdmEmailsDeserialize(String AEmails) throws IOException,ClassNotFoundException{
		ObjectInputStream in = null;
		try{
			in = new ObjectInputStream( new FileInputStream("C:\\Users\\AJAY KUMAR\\workspace\\Statis Gui\\src\\application\\"+AEmails+".txt"));
			return (AdminEmails) in.readObject();
		}
		finally{
			in.close();
		}
	}
	public static void AdmEmailsSerialize(String AEmails,AdminEmails PSerialize)throws IOException{
		ObjectOutputStream out = null;
		try{
			out = new ObjectOutputStream(new FileOutputStream("C:\\Users\\AJAY KUMAR\\workspace\\Statis Gui\\src\\application\\"+AEmails+".txt"));
			out.writeObject(PSerialize);
		}
		finally{
			out.close();
		}
		
		
	}
	public static AdminDataBase AdmDataDeserialize(String AData) throws IOException,ClassNotFoundException{
		ObjectInputStream in = null;
		try{
			in = new ObjectInputStream( new FileInputStream("C:\\Users\\AJAY KUMAR\\workspace\\Statis Gui\\src\\application\\"+AData+".txt"));
			return (AdminDataBase) in.readObject();
		}
		finally{
			in.close();
		}
	}
	public static void AdmDataSerialize(String AData,AdminDataBase PSerialize)throws IOException{
		ObjectOutputStream out = null;
		try{
			out = new ObjectOutputStream(new FileOutputStream("C:\\Users\\AJAY KUMAR\\workspace\\Statis Gui\\src\\application\\"+AData+".txt"));
			out.writeObject(PSerialize);
		}
		finally{
			out.close();
		}
		
		
	}

	public static AdminEmails getAdmEmails() {
		return AdmEmails;
	}

	public static void setAdmEmails(AdminEmails admEmails) {
		AdmEmails = admEmails;
	
	}
	
	
	public static AdminDataBase getAdmProfs() {
		return AdmProfs;
	}



	public static void setAdmProfs(AdminDataBase admProfs) {
		AdmProfs = admProfs;
	}



	public static FacultyEmails FacEmailsDeserialize(String FEmails) throws IOException,ClassNotFoundException{
		ObjectInputStream in = null;
		try{
			in = new ObjectInputStream( new FileInputStream("C:\\Users\\AJAY KUMAR\\workspace\\Statis Gui\\src\\application\\"+FEmails+".txt"));
			return (FacultyEmails) in.readObject();
		}
		finally{
			in.close();
		}
	}
	public static void FacEmailsSerialize(String FEmails,FacultyEmails PSerialize)throws IOException{
		ObjectOutputStream out = null;
		try{
			out = new ObjectOutputStream(new FileOutputStream("C:\\Users\\AJAY KUMAR\\workspace\\Statis Gui\\src\\application\\"+FEmails+".txt"));
			out.writeObject(PSerialize);
		}
		finally{
			out.close();
		}
		
		
	}
	
	public static FacultyDataBase FacDataDeserialize(String FData) throws IOException,ClassNotFoundException{
		ObjectInputStream in = null;
		try{
			in = new ObjectInputStream( new FileInputStream("C:\\Users\\AJAY KUMAR\\workspace\\Statis Gui\\src\\application\\"+FData+".txt"));
			return (FacultyDataBase) in.readObject();
		}
		finally{
			in.close();
		}
	}
	public static void FacDataSerialize(String FData,FacultyDataBase PSerialize)throws IOException{
		ObjectOutputStream out = null;
		try{
			out = new ObjectOutputStream(new FileOutputStream("C:\\Users\\AJAY KUMAR\\workspace\\Statis Gui\\src\\application\\"+FData+".txt"));
			out.writeObject(PSerialize);
		}
		finally{
			out.close();
		}
		
		
	}

	public static FacultyEmails getFacEmails() {
		return FacEmails;
	}

	public static void setFacEmails(FacultyEmails facEmails) {
		FacEmails = facEmails;
	
	}

	public static FacultyDataBase getFacProfs() {
		return FacProfs;
	}

	public static void setFacProfs(FacultyDataBase facProfs) {
		FacProfs = facProfs;
	}
	
	public static AllRoom AllRoomDataDeserialize(String AllRoomData) throws IOException,ClassNotFoundException{
		ObjectInputStream in = null;
		try{
			in = new ObjectInputStream( new FileInputStream("C:\\Users\\AJAY KUMAR\\workspace\\Statis Gui\\src\\application\\"+AllRoomData+".txt"));
			return (AllRoom) in.readObject();
		}
		finally{
			in.close();
		}
	}
	public static void AllRoomDataSerialize(String AllRoomData,AllRoom PSerialize)throws IOException{
		ObjectOutputStream out = null;
		try{
			out = new ObjectOutputStream(new FileOutputStream("C:\\Users\\AJAY KUMAR\\workspace\\Statis Gui\\src\\application\\"+AllRoomData+".txt"));
			out.writeObject(PSerialize);
		}
		finally{
			out.close();
		}
		
		
	}



	public static TimeTable getMainTimeTable() {
		return MainTimeTable;
	}



	public static void setMainTimeTable(TimeTable mainTimeTable) {
		MainTimeTable = mainTimeTable;
	}



	public static AllRoom getAllRooms() {
		return AllRooms;
	}



	public static void setAllRooms(AllRoom allRooms) {
		AllRooms = allRooms;
	}



	public static String getStudentSearch() {
		return StudentSearch;
	}



	public static void setStudentSearch(String studentSearch) {
		StudentSearch = studentSearch;
	}
	
	public static RoomRequestDataBase RoomRequestDataDeserialize(String ReqData) throws IOException,ClassNotFoundException{
		ObjectInputStream in = null;
		try{
			in = new ObjectInputStream( new FileInputStream("C:\\Users\\AJAY KUMAR\\workspace\\Statis Gui\\src\\application\\"+ReqData+".txt"));
			return (RoomRequestDataBase) in.readObject();
		}
		finally{
			in.close();
		}
	}
	public static void RoomRequestDataSerialize(String ReqData,RoomRequestDataBase PSerialize)throws IOException{
		ObjectOutputStream out = null;
		try{
			out = new ObjectOutputStream(new FileOutputStream("C:\\Users\\AJAY KUMAR\\workspace\\Statis Gui\\src\\application\\"+ReqData+".txt"));
			out.writeObject(PSerialize);
		}
		finally{
			out.close();
		}
		
		
	}



	public static RoomRequestDataBase getRoomRequests() {
		return RoomRequests;
	}



	public static void setRoomRequests(RoomRequestDataBase roomRequests) {
		RoomRequests = roomRequests;
	}
	
	
}


//------------------------------------------------Student Related Stuff------------------------------
class Student implements Serializable{
	private String Email;
	private int emlExist=0;
	Student(String em){
		this.Email = em;

	}
	public void Signup(){
		this.emlExist=1;
	}
	public int getEmlExist() {
		return emlExist;
	}
	public void setEmlExist(int emlExist) {
		this.emlExist = emlExist;
	}
	public String getEmail() {
		return Email;
	}
	
}



class StudentEmails implements Serializable{
	ArrayList Emails;
	StudentEmails() {
		this.Emails = new ArrayList<Student>();
	}
	public void addEmail(String em){
		this.Emails.add(new Student(em));
	}
	public Boolean search(String em){
		int len = Emails.size();
		for(int i = 0 ; i < len ; i++){
			if(em.equals(((Student)(Emails.get(i))).getEmail()) && ((Student)(Emails.get(i))).getEmlExist()==0){
				return true;
			}
		}
		return false;
//print wrong email or already registered
	}
	public void Register(String em){
		int len = Emails.size();
		for(int i = 0 ; i < len ; i++){
			if(em.equals(((Student)(Emails.get(i))).getEmail()) && ((Student)(Emails.get(i))).getEmlExist()==0){
				((Student)(Emails.get(i))).setEmlExist(1);
			}
		}
	}
	
}

class StudentProfile implements Serializable{
	String PassWord;
	ArrayList Courses;
	String Email;
	ArrayList Bookedrooms;
	ArrayList Reqs;
	StudentProfile(String em,String pass,TimeTable AllCourse){
		this.Email = em;
		this.PassWord = pass;
		this.Courses = new ArrayList<courses>();
		this.Bookedrooms = new ArrayList<String>();
		this.Reqs = new ArrayList<String>();
		int counter = Main.getMainTimeTable().getCourseData().size();
		for(int i = 0 ; i< counter ; i++){
			if("Mandatory".equals(((courses)(Main.getMainTimeTable().getCourseData().get(i))).getCourseType())){
				Courses.add(((courses)(Main.getMainTimeTable().getCourseData().get(i))));
			}
		}
		
	}
	
	public ArrayList getReqs() {
		return Reqs;
	}

	public void setReqs(ArrayList reqs) {
		Reqs = reqs;
	}

	public String getPassWord() {
		return PassWord;
	}
	public void setPassWord(String passWord) {
		PassWord = passWord;
	}
	public ArrayList getCourses() {
		return Courses;
	}
	public void setCourses(ArrayList courses) {
		Courses = courses;
	}
	public String getEmail() {
		return Email;
	}
	public void setEmail(String email) {
		Email = email;
	}
	public void add(String acro){
		int counter = Courses.size() ;
		for(int i = 0 ; i < counter ; i++){
			if(acro.equals(((courses)Courses.get(i)).getAcronym())){
				return;
			}
		}
		int count = Main.getMainTimeTable().getCourseData().size();
		for(int i = 0 ; i < count ; i++){
			if(acro.equals(((courses)(Main.getMainTimeTable().getCourseData().get(i))).getAcronym())){
				Courses.add(((courses)(Main.getMainTimeTable().getCourseData().get(i))));
			}
		}
		
	}
	public void delete(String acro){
		int counter = Courses.size();
		for(int i = 0 ; i < counter ; i++){
			if(acro.equals(((courses)Courses.get(i)).getAcronym())){
				Courses.remove(i);
			}
		}
	}
	public ArrayList getBookedrooms() {
		return Bookedrooms;
	}
	public void setBookedrooms(ArrayList bookedrooms) {
		Bookedrooms = bookedrooms;
	}
	
	
}


class StudentDataBase implements Serializable{
	private ArrayList StudentData;
	StudentDataBase(){
		this.StudentData = new ArrayList<StudentProfile>();
	}
	public ArrayList getStudentData() {
		return StudentData;
	}
	public void setAdminData(ArrayList studentData) {
		StudentData = studentData;
	}
	public int search(String email,String pass){
		int ret = -1;
		int len = StudentData.size(); 
		for(int i = 0 ; i < len ; i++){
			if(((StudentProfile)StudentData.get(i)).getEmail().equals(email) && ((StudentProfile)StudentData.get(i)).getPassWord().equals(pass)){
				return i ;
			}
		}
		return ret;
	}
	
}
//------------------------------------------------Admin Related Stuff------------------------------
class Admin implements Serializable{
	private String Email;
	private int emlExist=0;
	Admin(String em){
		this.Email = em;

	}
	public void Signup(){
		this.emlExist=1;
	}
	public int getEmlExist() {
		return emlExist;
	}
	public void setEmlExist(int emlExist) {
		this.emlExist = emlExist;
	}
	public String getEmail() {
		return Email;
	}
	
}



class AdminEmails implements Serializable{
	ArrayList Emails;
	AdminEmails() {
		this.Emails = new ArrayList<Admin>();
	}
	public void addEmail(String em){
		this.Emails.add(new Admin(em));
	}
	public Boolean search(String em){
		int len = Emails.size();
		for(int i = 0 ; i < len ; i++){
			if(em.equals(((Admin)(Emails.get(i))).getEmail()) && ((Admin)(Emails.get(i))).getEmlExist()==0){
				return true;
			}
		}
		return false;
//print wrong email or already registered
	}
	public void Register(String em){
		int len = Emails.size();
		for(int i = 0 ; i < len ; i++){
			if(em.equals(((Admin)(Emails.get(i))).getEmail()) && ((Admin)(Emails.get(i))).getEmlExist()==0){
				((Admin)(Emails.get(i))).setEmlExist(1);
			}
		}
	}
}

class AdminProfile implements Serializable{
	String PassWord;
	ArrayList Courses;
	String Email;
	ArrayList Bookedrooms;
	AdminProfile(String em,String pass){
		this.Email = em;
		this.PassWord = pass;
		this.Bookedrooms = new ArrayList<String>();
	}
	public String getPassWord() {
		return PassWord;
	}
	public void setPassWord(String passWord) {
		PassWord = passWord;
	}
	public ArrayList getCourses() {
		return Courses;
	}
	public void setCourses(ArrayList courses) {
		Courses = courses;
	}
	public String getEmail() {
		return Email;
	}
	public void setEmail(String email) {
		Email = email;
	}
	public ArrayList getBookedrooms() {
		return Bookedrooms;
	}
	public void setBookedrooms(ArrayList bookedrooms) {
		this.Bookedrooms = bookedrooms;
	}
	
	
}


class AdminDataBase implements Serializable{
	private ArrayList AdminData;
	AdminDataBase(){
		this.AdminData = new ArrayList<AdminProfile>();
	}
	public ArrayList getAdminData() {
		return AdminData;
	}
	public void setAdminData(ArrayList adminData) {
		AdminData = adminData;
	}
	public int search(String email,String pass){
		int ret = -1;
		int len = AdminData.size(); 
		for(int i = 0 ; i < len ; i++){
			if(((AdminProfile)AdminData.get(i)).getEmail().equals(email) && ((AdminProfile)AdminData.get(i)).getPassWord().equals(pass)){
				return i ;
			}
		}
		return ret;
	}
	
}
//------------------------------------------------Faculty Related Stuff------------------------------
class Faculty implements Serializable{
	private String Email;
	private int emlExist=0;
	Faculty(String em){
		this.Email = em;

	}
	public void Signup(){
		this.emlExist=1;
	}
	public int getEmlExist() {
		return emlExist;
	}
	public void setEmlExist(int emlExist) {
		this.emlExist = emlExist;
	}
	public String getEmail() {
		return Email;
	}
	
}



class FacultyEmails implements Serializable{
	ArrayList Emails;
	FacultyEmails() {
		this.Emails = new ArrayList<Faculty>();
	}
	public void addEmail(String em){
		this.Emails.add(new Faculty(em));
	}
	public Boolean search(String em){
		int len = Emails.size();
		for(int i = 0 ; i < len ; i++){
			if(em.equals(((Faculty)(Emails.get(i))).getEmail()) && ((Faculty)(Emails.get(i))).getEmlExist()==0){
				return true;
			}
		}
		return false;
//print wrong email or already registered
	}
	public void Register(String em){
		int len = Emails.size();
		for(int i = 0 ; i < len ; i++){
			if(em.equals(((Faculty)(Emails.get(i))).getEmail()) && ((Faculty)(Emails.get(i))).getEmlExist()==0){
				((Faculty)(Emails.get(i))).setEmlExist(1);
			}
		}
	}
}

class FacultyProfile implements Serializable{
	String PassWord;
	ArrayList Courses;
	String Email;
	ArrayList bookedrooms;
	FacultyProfile(String em,String pass){
		this.Email = em;
		this.PassWord = pass;
		this.Courses = new ArrayList<courses>();
		this.bookedrooms = new ArrayList<String>();
	}
	public String getPassWord() {
		return PassWord;
	}
	public void setPassWord(String passWord) {
		PassWord = passWord;
	}
	public ArrayList getCourses() {
		return Courses;
	}
	public void setCourses(ArrayList courses) {
		Courses = courses;
	}
	public String getEmail() {
		return Email;
	}
	public void setEmail(String email) {
		Email = email;
	}
	public ArrayList getBookedrooms() {
		return bookedrooms;
	}
	public void setBookedrooms(ArrayList bookedrooms) {
		this.bookedrooms = bookedrooms;
	}
	public void add(String acro){
		int counter = Courses.size() ;
		for(int i = 0 ; i < counter ; i++){
			if(acro.equals(((courses)Courses.get(i)).getAcronym())){
				return;
			}
		}
		int count = Main.getMainTimeTable().getCourseData().size();
		for(int i = 0 ; i < count ; i++){
			if(acro.equals(((courses)(Main.getMainTimeTable().getCourseData().get(i))).getAcronym())){
				Courses.add(((courses)(Main.getMainTimeTable().getCourseData().get(i))));
			}
		}
		
	}
	public void delete(String acro){
		int counter = Courses.size();
		for(int i = 0 ; i < counter ; i++){
			if(acro.equals(((courses)Courses.get(i)).getAcronym())){
				Courses.remove(i);
			}
		}
	}
	
}


class FacultyDataBase implements Serializable{
	private ArrayList FacultyData;
	FacultyDataBase(){
		this.FacultyData = new ArrayList<FacultyProfile>();
	}
	public ArrayList getFacultyData() {
		return FacultyData;
	}
	public void setFacultyData(ArrayList facultyData) {
		FacultyData = facultyData;
	}
	public int search(String email,String pass){
		int ret = -1;
		int len = FacultyData.size(); 
		for(int i = 0 ; i < len ; i++){
			if(((FacultyProfile)FacultyData.get(i)).getEmail().equals(email) && ((FacultyProfile)FacultyData.get(i)).getPassWord().equals(pass)){
				return i ;
			}
		}
		return ret;
	}
	
}
//--------------------------------------------------------------------------------------------------------------------
class DayAndTime implements Serializable{
	private String day;
	private String start;
	private String end;
	public DayAndTime(String d,String s,String e) {
		this.day = d;
		this.start = s;
		this.end = e;
	}
}
class Room implements Serializable{
	String RoomNo;
	private int capacity;
	int[][] roomTimings;
	String[][] CourseTimings;
	Room(String roomno,int cap){
		this.RoomNo = roomno;
		this.capacity = cap;
		this.roomTimings = new int[5][17];
		this.CourseTimings = new String[5][17];
	}
	public String getRoomNo() {
		return RoomNo;
	}
	public void setRoomNo(String roomNo) {
		RoomNo = roomNo;
	}
	public int getCapacity() {
		return capacity;
	}
	public void setCapacity(int capacity) {
		this.capacity = capacity;
	}
	public int[][] getRoomTimings() {
		return roomTimings;
	}
	public void setRoomTimings(int[][] roomTimings) {
		this.roomTimings = roomTimings;
	}
	
	public String[][] getCourseTimings() {
		return CourseTimings;
	}
	public void setCourseTimings(String[][] courseTimings) {
		CourseTimings = courseTimings;
	}
	public void TimAdd(int day,String tim){
		String[] all = tim.split("-");
		String[] start = (all[0]).split(":");
		String[] end = (all[1]).split(":");
		int ext = Integer.parseInt(start[1])/30;
		int strt = Integer.parseInt(start[0]);
		if(strt<=6){
			strt+=12;
		}
		int startIndex = (strt-9)*2-1+ext;
		int extrt = Integer.parseInt(end[0]);
		if(extrt<=6){
			extrt+=12;
		}
		int endext = (Integer.parseInt(end[1])/30)-ext;
		int endIndex = startIndex +(extrt-strt)*2+endext;
		for(int i = startIndex ; i<endIndex;i++ ){
			this.roomTimings[day][i] = 1;
		}
	}
	
	public void remove(int day,String sta,String en){
		String[] start = (sta).split(":");
		String[] end = (en).split(":");
		int ext = Integer.parseInt(start[1])/30;
		int strt = Integer.parseInt(start[0]);
		if(strt<=6){
			strt+=12;
		}
		int startIndex = (strt-9)*2-1+ext;
		int extrt = Integer.parseInt(end[0]);
		if(extrt<=6){
			extrt+=12;
		}
		int endext = (Integer.parseInt(end[1])/30)-ext;
		int endIndex = startIndex +(extrt-strt)*2+endext;
		for(int i = startIndex ; i<endIndex;i++ ){
			this.roomTimings[day][i] = 0;
		}
	}
	public void CourseTimAdd(int day,String tim,String course){
		String[] all = tim.split("-");
		String[] start = (all[0]).split(":");
		String[] end = (all[1]).split(":");
		int ext = Integer.parseInt(start[1])/30;
		int strt = Integer.parseInt(start[0]);
		if(strt<=6){
			strt+=12;
		}
		int startIndex = (strt-9)*2-1+ext;
		int extrt = Integer.parseInt(end[0]);
		if(extrt<=6){
			extrt+=12;
		}
		int endext = (Integer.parseInt(end[1])/30)-ext;
		int endIndex = startIndex +(extrt-strt)*2+endext;
		for(int i = startIndex ; i<endIndex;i++ ){
			this.CourseTimings[day][i] = course;
		}
	}
	
}
class courses implements Serializable{
	private String CourseName;
	private String CourseCode;
	private String preConditions;
	private String postConditions;
	private String CourseType;
	private String Credits;
	private String Acronym;
	private String Mon;
	private String Tue;
	private String Wed;
	private String Thur;
	private String Fri;
	private String Tut;
	private String Lab;
	private String Instructor;
	
	public courses(String typ,String CN,String CC,String instr,String Cred,String Acrym,String M,String T,String W,String Th,String F,String tut,String lab,String pre,String post) {
		this.CourseType = typ;
		this.CourseName = CN;
		this.CourseCode = CC;
		this.Instructor = instr;
		this.Acronym = Acrym;
		this.Mon = M;
		this.Tue = T;
		this.Wed = W;
		this.Thur = Th;
		this.Fri = F;
		this.Lab = lab;
		this.Tut = tut;
		this.preConditions = pre;
		this.postConditions = post;
	}
	public String getCourseName() {
		return CourseName;
	}
	public void setCourseName(String courseName) {
		CourseName = courseName;
	}
	public String getCourseCode() {
		return CourseCode;
	}
	public void setCourseCode(String courseCode) {
		CourseCode = courseCode;
	}
	public String getPreConditions() {
		return preConditions;
	}
	public void setPreConditions(String preConditions) {
		this.preConditions = preConditions;
	}
	public String getPostConditions() {
		return postConditions;
	}
	public void setPostConditions(String postConditions) {
		this.postConditions = postConditions;
	}
	public String getCourseType() {
		return CourseType;
	}
	public void setCourseType(String courseType) {
		CourseType = courseType;
	}
	public String getCredits() {
		return Credits;
	}
	public void setCredits(String credits) {
		Credits = credits;
	}
	public String getAcronym() {
		return Acronym;
	}
	public void setAcronym(String acronym) {
		Acronym = acronym;
	}
	public String getMon() {
		return Mon;
	}
	public void setMon(String mon) {
		Mon = mon;
	}
	public String getTue() {
		return Tue;
	}
	public void setTue(String tue) {
		Tue = tue;
	}
	public String getWed() {
		return Wed;
	}
	public void setWed(String wed) {
		Wed = wed;
	}
	public String getThur() {
		return Thur;
	}
	public void setThur(String thur) {
		Thur = thur;
	}
	public String getFri() {
		return Fri;
	}
	public void setFri(String fri) {
		Fri = fri;
	}
	
	public String getTut() {
		return Tut;
	}
	public void setTut(String tut) {
		Tut = tut;
	}
	public String getLab() {
		return Lab;
	}
	public void setLab(String lab) {
		Lab = lab;
	}
	public String getInstructor() {
		return Instructor;
	}
	public void setInstructor(String instructor) {
		Instructor = instructor;
	}
		
}
class TimeTable implements Serializable{
	private ArrayList CourseData;
	TimeTable(){
		this.CourseData = new ArrayList<courses>();
	}
	public ArrayList getCourseData() {
		return CourseData;
	}
	public void setCourseData(ArrayList courseData) {
		CourseData = courseData;
	}
	
}
class AllRoom implements Serializable{
	private ArrayList rooms;
	AllRoom(){
		rooms = new ArrayList<Room>();
	}
	public ArrayList getRooms() {
		return rooms;
	}
	public void setRooms(ArrayList rooms) {
		this.rooms = rooms;
	}
	public void TimingRoomAdd(int day,String tim){
		String[] all = tim.split("_");
		String roo = all[1];
		int no = search(roo);
		((Room)rooms.get(no)).TimAdd(day, all[0]);
		//System.out.println(tim);
		
	}
	public void TimingCourseAdd(int day,String tim,String course){
		String[] all = tim.split("_");
		String roo = all[1];
		int no = search(roo);
		((Room)rooms.get(no)).CourseTimAdd(day, all[0],course);
		
	}
	public int search(String rooNo){
		int counter = rooms.size();
		for(int i = 0 ; i < counter ; i++){
			if(rooNo.equals(((Room)rooms.get(i)).getRoomNo())){
				return i;
			}
		}
		
		
		return 0;
		
	}
	public void TimingRoomRemove(String day,String roo,String start,String end ){
		int no = search(roo);
		if(day.equals("Monday")){
			try{
				((Room)rooms.get(no)).remove(0, start, end);
			}
			catch(Exception e){
				
			}
		}
		else if(day.equals("Tuesday")){
			try{
				((Room)rooms.get(no)).remove(1, start, end);
			}
			catch(Exception e){
				
			}
		}
		else if(day.equals("Wednesday")){
			try{
				((Room)rooms.get(no)).remove(2, start, end);
			}
			catch(Exception e){
				
			}
		}
		else if(day.equals("Thursday")){
			try{
				((Room)rooms.get(no)).remove(3, start, end);
			}
			catch(Exception e){
				
			}
		}
		else{
			try{
				((Room)rooms.get(no)).remove(4, start, end);
			}
			catch(Exception e){
				
			}
		}
		
	}

	
}
		
class RoomRequest implements Serializable{
	private String Email;
	private int Emailno;
	private String RoomNo;
	private String Day;
	private String StartTime;
	private String EndTime;
	RoomRequest(int Eno,String rno,String d,String s,String e){
		this.Emailno = Eno;
		this.RoomNo = rno;
		this.Day = d;
		this.StartTime = s;
		this.EndTime = e;
		this.Email = ((StudentProfile)(Main.getStuProfs().getStudentData().get(Emailno))).getEmail();
		
	}
	public String net(){
		String ret = this.Email+"_"+this.Day+"_"+this.StartTime+"-"+this.EndTime+"_"+this.RoomNo;
		return ret;
	}
	public String getEmail() {
		return Email;
	}
	public void setEmail(String email) {
		Email = email;
	}
	public int getEmailno() {
		return Emailno;
	}
	public void setEmailno(int emailno) {
		Emailno = emailno;
	}
	public String getRoomNo() {
		return RoomNo;
	}
	public void setRoomNo(String roomNo) {
		RoomNo = roomNo;
	}
	public String getDay() {
		return Day;
	}
	public void setDay(String day) {
		Day = day;
	}
	public String getStartTime() {
		return StartTime;
	}
	public void setStartTime(String startTime) {
		StartTime = startTime;
	}
	public String getEndTime() {
		return EndTime;
	}
	public void setEndTime(String endTime) {
		EndTime = endTime;
	}

	
}

class RoomRequestDataBase implements Serializable{
	private ArrayList Requests;
	RoomRequestDataBase(){
		Requests = new ArrayList<RoomRequest>();
	}
	public ArrayList getRequests() {
		return Requests;
	}
	public void setRequests(ArrayList requests) {
		Requests = requests;
	}
	
}