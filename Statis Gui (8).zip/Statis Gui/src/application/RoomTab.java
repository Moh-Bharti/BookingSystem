package application;

public class RoomTab {
	private final String t1;
	private final String t2;
	private final String t3;
	private final String t4;
	private final String t5;
	private final String t6;
	private final String t7;
	private final String t8;
	private final String t9;
	private final String t10;
	private final String t11;
	private final String t12;
	private final String t13;
	private final String t14;
	private final String t15;
	private final String t16;
	private final String t17;
	private final String t18;
	RoomTab(String tt1,String tt2,String tt3,String tt4,String tt5,String tt6,String tt7,String tt8,String tt9,String tt10,String tt11,String tt12,String tt13,String tt14,String tt15,String tt16,String tt17,String tt18){
		this.t1 = tt1;
		this.t2 = tt2;
		this.t3 = tt3;
		this.t4 = tt4;
		this.t5 = tt5;
		this.t6 = tt6;
		this.t7 = tt7;
		this.t8 = tt8;
		this.t9 = tt9;
		this.t10 = tt10;
		this.t11 = tt11;
		this.t12 = tt12;
		this.t13 = tt13;
		this.t14 = tt14;
		this.t15 = tt15;
		this.t16 = tt16;
		this.t17 = tt17;
		this.t18 = tt18;
	}
	public String getT1() {
		return t1;
	}
	public String getT2() {
		return t2;
	}
	public String getT3() {
		return t3;
	}
	public String getT4() {
		return t4;
	}
	public String getT5() {
		return t5;
	}
	public String getT6() {
		return t6;
	}
	public String getT7() {
		return t7;
	}
	public String getT8() {
		return t8;
	}
	public String getT9() {
		return t9;
	}
	public String getT10() {
		return t10;
	}
	public String getT11() {
		return t11;
	}
	public String getT12() {
		return t12;
	}
	public String getT13() {
		return t13;
	}
	public String getT14() {
		return t14;
	}
	public String getT15() {
		return t15;
	}
	public String getT16() {
		return t16;
	}
	public String getT17() {
		return t17;
	}
	public String getT18() {
		return t18;
	}
	
}
